import React from 'react';
import { useParams, Link } from 'react-router-dom';
import { ArrowLeft, Clock, User, Calendar, Share2, BookOpen, Heart } from 'lucide-react';

interface Article {
  id: string;
  title: string;
  content: string;
  image: string;
  author: string;
  publishDate: string;
  readTime: string;
  category: string;
  tags: string[];
}

const ArticleDetailPage: React.FC = () => {
  const { id } = useParams<{ id: string }>();

  // Sample article data - in a real app, this would come from an API
  const articles: Record<string, Article> = {
    '1': {
      id: '1',
      title: 'Foods Rich in Vitamin Bs may help reduce PMS',
      content: `
        <p>Pre-menstrual syndrome (PMS) affects millions of women worldwide, causing a range of uncomfortable symptoms that can significantly impact daily life. While there's no one-size-fits-all solution, emerging research suggests that certain B vitamins may play a crucial role in managing PMS symptoms.</p>

        <h2>Understanding PMS and Nutrition</h2>
        <p>PMS encompasses a variety of physical and emotional symptoms that typically occur in the luteal phase of the menstrual cycle. These can include mood swings, bloating, breast tenderness, fatigue, and food cravings. The exact cause of PMS isn't fully understood, but hormonal fluctuations, particularly in estrogen and progesterone levels, are believed to play a significant role.</p>

        <p>Nutrition has long been recognized as an important factor in managing PMS symptoms. Certain nutrients, including B vitamins, may help support the body's natural processes during this challenging time.</p>

        <h2>The Role of B Vitamins</h2>
        <p>B vitamins are a group of water-soluble vitamins that play essential roles in energy metabolism, nervous system function, and hormone regulation. Several B vitamins have been specifically studied for their potential benefits in managing PMS:</p>

        <h3>Vitamin B6 (Pyridoxine)</h3>
        <p>Vitamin B6 is perhaps the most well-researched B vitamin for PMS relief. It's involved in the production of neurotransmitters like serotonin and dopamine, which can affect mood and emotional well-being. Studies have shown that vitamin B6 supplementation may help reduce mood-related PMS symptoms, including irritability, depression, and anxiety.</p>

        <h3>Vitamin B1 (Thiamine)</h3>
        <p>Research has indicated that women with higher intakes of thiamine may experience less severe PMS symptoms. This vitamin is crucial for energy metabolism and nervous system function, which may explain its potential benefits.</p>

        <h3>Vitamin B2 (Riboflavin)</h3>
        <p>Like thiamine, riboflavin has been associated with reduced PMS symptom severity in some studies. It plays a vital role in energy production and may help combat the fatigue often experienced during PMS.</p>

        <h2>Food Sources of B Vitamins</h2>
        <p>Incorporating B vitamin-rich foods into your diet is a natural way to potentially support PMS management:</p>

        <ul>
          <li><strong>Vitamin B6:</strong> Chickpeas, tuna, salmon, chicken breast, potatoes, bananas</li>
          <li><strong>Vitamin B1:</strong> Whole grains, pork, sunflower seeds, beans, peas</li>
          <li><strong>Vitamin B2:</strong> Dairy products, eggs, leafy greens, almonds, mushrooms</li>
          <li><strong>Folate (B9):</strong> Dark leafy greens, legumes, fortified cereals, asparagus</li>
          <li><strong>Vitamin B12:</strong> Fish, meat, dairy products, fortified plant-based foods</li>
        </ul>

        <h2>Practical Tips for Implementation</h2>
        <p>To maximize the potential benefits of B vitamins for PMS management:</p>

        <ol>
          <li><strong>Maintain a balanced diet:</strong> Focus on whole foods that naturally contain B vitamins rather than relying solely on supplements.</li>
          <li><strong>Consider timing:</strong> Some women find it helpful to increase their B vitamin intake in the weeks leading up to their period.</li>
          <li><strong>Stay consistent:</strong> Regular intake of B vitamin-rich foods may be more beneficial than sporadic consumption.</li>
          <li><strong>Combine with other healthy habits:</strong> B vitamins work best as part of an overall healthy lifestyle that includes regular exercise, adequate sleep, and stress management.</li>
        </ol>

        <h2>When to Consider Supplements</h2>
        <p>While food sources are generally preferred, some women may benefit from B vitamin supplements, particularly if their diet is lacking in these nutrients. It's important to consult with a healthcare professional before starting any supplement regimen, especially if you're taking other medications or have underlying health conditions.</p>

        <h2>The Bottom Line</h2>
        <p>While more research is needed to fully understand the relationship between B vitamins and PMS, the current evidence suggests that maintaining adequate levels of these essential nutrients may help some women manage their symptoms more effectively. By incorporating B vitamin-rich foods into your diet and maintaining overall healthy habits, you may find some relief from the monthly challenges of PMS.</p>

        <p>Remember, every woman's experience with PMS is unique, and what works for one person may not work for another. If you're struggling with severe PMS symptoms, it's always best to consult with a healthcare professional who can provide personalized advice and treatment options.</p>
      `,
      image: 'https://images.pexels.com/photos/1640777/pexels-photo-1640777.jpeg?auto=compress&cs=tinysrgb&w=800',
      author: 'Dr. Sarah Johnson',
      publishDate: '2025-01-20',
      readTime: '5 min read',
      category: "Women's health",
      tags: ['PMS', 'Vitamin B', 'Nutrition', 'Women\'s Health', 'Natural Health']
    },
    '4': {
      id: '4',
      title: 'Everything to Know About Getting Off Contraception to Conceive',
      content: `
        <p>Making the decision to start trying for a baby is an exciting milestone, but it often comes with questions about how your current contraceptive method might affect your fertility. Understanding what to expect when discontinuing contraception can help you plan your journey to conception more effectively.</p>

        <h2>Different Contraceptive Methods and Fertility Return</h2>
        
        <h3>Hormonal Contraceptives</h3>
        <p>Hormonal contraceptives, including the pill, patch, ring, and hormonal IUDs, work by suppressing ovulation and altering hormone levels. When you stop using these methods:</p>
        
        <ul>
          <li><strong>The Pill:</strong> Most women resume normal ovulation within 1-3 months after stopping the pill. Some may conceive immediately, while others may take a few cycles for their natural rhythm to return.</li>
          <li><strong>Hormonal IUD:</strong> Fertility typically returns quickly after removal, often within the first month.</li>
          <li><strong>Contraceptive Injection:</strong> This method can take longer to wear off, with fertility potentially taking 6-18 months to return to normal.</li>
        </ul>

        <h3>Non-Hormonal Methods</h3>
        <p>Non-hormonal contraceptives generally don't affect your natural fertility:</p>
        
        <ul>
          <li><strong>Copper IUD:</strong> Fertility returns immediately after removal.</li>
          <li><strong>Barrier methods:</strong> Condoms, diaphragms, and cervical caps don't affect fertility and can be discontinued at any time.</li>
        </ul>

        <h2>Preparing Your Body for Conception</h2>
        
        <h3>Start Taking Folic Acid</h3>
        <p>Begin taking folic acid supplements at least one month before trying to conceive. The recommended dose is 400-800 micrograms daily, which helps prevent neural tube defects in developing babies.</p>

        <h3>Maintain a Healthy Lifestyle</h3>
        <p>Focus on:</p>
        <ul>
          <li>Eating a balanced, nutrient-rich diet</li>
          <li>Maintaining a healthy weight</li>
          <li>Regular moderate exercise</li>
          <li>Limiting alcohol and avoiding smoking</li>
          <li>Managing stress levels</li>
          <li>Getting adequate sleep</li>
        </ul>

        <h3>Track Your Cycle</h3>
        <p>Start tracking your menstrual cycle to understand your natural rhythm. This can help you identify your fertile window and optimize your chances of conception.</p>

        <h2>What to Expect After Stopping Contraception</h2>
        
        <h3>Irregular Periods Initially</h3>
        <p>It's normal for your periods to be irregular for the first few months after stopping hormonal contraception. Your body needs time to readjust to its natural hormone production.</p>

        <h3>Return of Pre-Contraception Symptoms</h3>
        <p>Symptoms you experienced before starting contraception, such as acne, heavier periods, or PMS, may return. This is normal and indicates your body is returning to its natural state.</p>

        <h3>Withdrawal Bleeding</h3>
        <p>You may experience some irregular bleeding or spotting as your body adjusts. This is typically temporary and should resolve within a few cycles.</p>

        <h2>When to Seek Professional Advice</h2>
        
        <p>Consider consulting with a healthcare professional if:</p>
        <ul>
          <li>Your periods don't return within 3-6 months of stopping contraception</li>
          <li>You experience severe or concerning symptoms</li>
          <li>You have underlying health conditions that might affect fertility</li>
          <li>You're over 35 and want to optimize your conception timeline</li>
          <li>You have questions about preconception health</li>
        </ul>

        <h2>Supporting Your Fertility Journey</h2>
        
        <p>While waiting for your natural cycle to return, focus on creating the best possible environment for conception:</p>
        
        <ul>
          <li><strong>Nutrition:</strong> Ensure adequate intake of key nutrients like folate, iron, vitamin D, and omega-3 fatty acids</li>
          <li><strong>Stress Management:</strong> Practice relaxation techniques, meditation, or yoga</li>
          <li><strong>Regular Check-ups:</strong> Schedule a preconception health check with your healthcare provider</li>
          <li><strong>Partner Health:</strong> Remember that male fertility is equally important - encourage your partner to adopt healthy habits too</li>
        </ul>

        <h2>The Timeline Reality</h2>
        
        <p>It's important to have realistic expectations about conception timing. For healthy couples under 35, it's normal for conception to take up to 12 months. Age, overall health, and individual factors all play a role in fertility.</p>

        <p>Remember, every woman's body is different, and there's no universal timeline for when fertility returns after contraception. Be patient with your body as it readjusts, and don't hesitate to seek professional guidance if you have concerns.</p>

        <h2>Conclusion</h2>
        
        <p>Transitioning off contraception to try for a baby is a significant step that requires patience and preparation. By understanding what to expect and taking proactive steps to support your health, you're setting yourself up for the best possible outcome on your fertility journey.</p>
      `,
      image: 'https://images.pexels.com/photos/1556691/pexels-photo-1556691.jpeg?auto=compress&cs=tinysrgb&w=800',
      author: 'Dr. Emily Chen',
      publishDate: '2023-03-08',
      readTime: '7 min read',
      category: "Women's health",
      tags: ['Contraception', 'Fertility', 'Conception', 'Family Planning', 'Women\'s Health']
    },
    '5': {
      id: '5',
      title: 'Easing pre menstrual headaches',
      content: `
        <p>Pre-menstrual headaches are a common and often debilitating symptom experienced by many women. Understanding the connection between hormonal changes and headaches can help you develop effective strategies for prevention and management.</p>

        <h2>The Hormonal Connection</h2>
        <p>Nearly 50 percent of headaches and migraines experienced by women occur around the time of either ovulation or menstruation. This timing strongly suggests a link between hormonal fluctuations and headache occurrence.</p>

        <p>The primary culprits are the dramatic changes in estrogen and progesterone levels that occur throughout the menstrual cycle. As these hormone levels drop just before menstruation, they can trigger headaches in susceptible women.</p>

        <h2>Types of Menstrual Headaches</h2>
        
        <h3>Menstrual Migraines</h3>
        <p>These are severe headaches that occur specifically in relation to the menstrual cycle. They're often more intense and longer-lasting than regular headaches and may be accompanied by:</p>
        <ul>
          <li>Nausea and vomiting</li>
          <li>Sensitivity to light and sound</li>
          <li>Visual disturbances (aura)</li>
          <li>Throbbing pain, usually on one side of the head</li>
        </ul>

        <h3>Tension Headaches</h3>
        <p>These are more common and typically present as:</p>
        <ul>
          <li>Dull, aching pain across the forehead or back of the head</li>
          <li>Feeling of tightness or pressure</li>
          <li>Muscle tension in the neck and shoulders</li>
        </ul>

        <h2>Natural Management Strategies</h2>
        
        <h3>Dietary Approaches</h3>
        <p>What you eat can significantly impact the frequency and severity of pre-menstrual headaches:</p>
        
        <ul>
          <li><strong>Maintain stable blood sugar:</strong> Eat regular, balanced meals to prevent blood sugar fluctuations that can trigger headaches</li>
          <li><strong>Stay hydrated:</strong> Dehydration is a common headache trigger, so aim for 8-10 glasses of water daily</li>
          <li><strong>Limit trigger foods:</strong> Common triggers include aged cheeses, processed meats, chocolate, and foods containing MSG</li>
          <li><strong>Increase magnesium intake:</strong> Foods rich in magnesium, such as leafy greens, nuts, and seeds, may help prevent headaches</li>
        </ul>

        <h3>Lifestyle Modifications</h3>
        
        <h4>Sleep Hygiene</h4>
        <p>Maintaining consistent sleep patterns is crucial for headache prevention:</p>
        <ul>
          <li>Aim for 7-9 hours of sleep nightly</li>
          <li>Keep a regular sleep schedule, even on weekends</li>
          <li>Create a relaxing bedtime routine</li>
          <li>Ensure your sleeping environment is cool, dark, and quiet</li>
        </ul>

        <h4>Stress Management</h4>
        <p>Stress can exacerbate hormonal fluctuations and trigger headaches. Effective stress management techniques include:</p>
        <ul>
          <li>Regular meditation or mindfulness practice</li>
          <li>Deep breathing exercises</li>
          <li>Yoga or gentle stretching</li>
          <li>Regular physical activity</li>
          <li>Journaling or other creative outlets</li>
        </ul>

        <h2>Natural Supplements and Remedies</h2>
        
        <h3>Magnesium</h3>
        <p>Magnesium deficiency has been linked to increased headache frequency. Supplementing with magnesium may help reduce both the frequency and intensity of menstrual headaches.</p>

        <h3>Vitamin B2 (Riboflavin)</h3>
        <p>Studies have shown that riboflavin supplementation may help reduce migraine frequency when taken consistently over several months.</p>

        <h3>Herbal Remedies</h3>
        <p>Several herbs have traditionally been used for headache relief:</p>
        <ul>
          <li><strong>Feverfew:</strong> May help prevent migraines when taken regularly</li>
          <li><strong>Ginger:</strong> Can help reduce nausea associated with migraines</li>
          <li><strong>Peppermint oil:</strong> Applied topically to temples may provide relief</li>
        </ul>

        <h2>When to Seek Professional Help</h2>
        
        <p>While many women can manage pre-menstrual headaches with natural approaches, it's important to consult a healthcare professional if:</p>
        <ul>
          <li>Headaches are severe or debilitating</li>
          <li>They significantly interfere with daily activities</li>
          <li>You experience sudden changes in headache patterns</li>
          <li>Natural remedies aren't providing adequate relief</li>
          <li>You have other concerning symptoms</li>
        </ul>

        <h2>Creating Your Personal Management Plan</h2>
        
        <p>Developing an effective strategy for managing pre-menstrual headaches often requires a personalized approach:</p>
        
        <ol>
          <li><strong>Track your symptoms:</strong> Keep a headache diary to identify patterns and triggers</li>
          <li><strong>Implement preventive measures:</strong> Start dietary and lifestyle changes before your symptoms typically begin</li>
          <li><strong>Have a treatment plan ready:</strong> Know what works for you when a headache does occur</li>
          <li><strong>Be patient:</strong> Natural approaches often take time to show their full benefits</li>
        </ol>

        <h2>Conclusion</h2>
        
        <p>Pre-menstrual headaches don't have to control your life. By understanding the hormonal connections and implementing natural management strategies, many women find significant relief from their symptoms. Remember that what works best can vary from person to person, so be patient as you discover the most effective approach for your individual needs.</p>

        <p>If natural approaches aren't providing adequate relief, don't hesitate to work with a healthcare professional to explore additional treatment options. Your comfort and quality of life are important, and effective help is available.</p>
      `,
      image: 'https://images.pexels.com/photos/3768114/pexels-photo-3768114.jpeg?auto=compress&cs=tinysrgb&w=800',
      author: 'Jennifer McLennan',
      publishDate: '2024-10-30',
      readTime: '6 min read',
      category: "Women's health",
      tags: ['Headaches', 'PMS', 'Hormones', 'Natural Remedies', 'Women\'s Health']
    }
  };

  const article = articles[id || ''];

  if (!article) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-2xl font-bold text-gray-900 mb-2">Article not found</h1>
          <p className="text-gray-600 mb-6">The article you're looking for doesn't exist.</p>
          <Link
            to="/womens-health"
            className="bg-blackmores-teal text-white px-6 py-3 rounded-lg hover:bg-blackmores-teal-dark transition-colors"
          >
            Back to Women's Health
          </Link>
        </div>
      </div>
    );
  }

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Breadcrumb */}
      <div className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center space-x-2 text-sm">
            <Link to="/" className="text-blackmores-teal hover:text-blackmores-teal-dark">
              Health hub
            </Link>
            <span className="text-gray-400">/</span>
            <Link to="/womens-health" className="text-blackmores-teal hover:text-blackmores-teal-dark">
              Women's health
            </Link>
            <span className="text-gray-400">/</span>
            <span className="text-gray-900 font-medium">Article</span>
          </div>
        </div>
      </div>

      {/* Back Button */}
      <div className="bg-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <Link
            to="/womens-health"
            className="inline-flex items-center text-blackmores-teal hover:text-blackmores-teal-dark transition-colors group"
          >
            <ArrowLeft className="w-5 h-5 mr-2 group-hover:-translate-x-1 transition-transform" />
            Back to Women's Health
          </Link>
        </div>
      </div>

      {/* Article Content */}
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 pb-16">
        <article className="bg-white rounded-lg shadow-sm overflow-hidden">
          {/* Hero Image */}
          <div className="h-64 md:h-80 overflow-hidden">
            <img
              src={article.image}
              alt={article.title}
              className="w-full h-full object-cover"
            />
          </div>

          {/* Article Header */}
          <div className="p-8">
            <div className="mb-4">
              <span className="text-sm text-blackmores-teal font-medium bg-green-50 px-3 py-1 rounded-full">
                {article.category}
              </span>
            </div>

            <h1 className="text-3xl md:text-4xl font-bold text-gray-900 mb-6 leading-tight">
              {article.title}
            </h1>

            {/* Article Meta */}
            <div className="flex flex-wrap items-center text-sm text-gray-600 mb-8 space-x-6">
              <div className="flex items-center space-x-2">
                <User className="w-4 h-4" />
                <span>{article.author}</span>
              </div>
              <div className="flex items-center space-x-2">
                <Calendar className="w-4 h-4" />
                <span>{formatDate(article.publishDate)}</span>
              </div>
              <div className="flex items-center space-x-2">
                <Clock className="w-4 h-4" />
                <span>{article.readTime}</span>
              </div>
            </div>

            {/* Article Actions */}
            <div className="flex items-center justify-between border-b border-gray-200 pb-6 mb-8">
              <div className="flex items-center space-x-4">
                <button className="flex items-center space-x-2 text-gray-600 hover:text-blackmores-teal transition-colors">
                  <Share2 className="w-5 h-5" />
                  <span>Share</span>
                </button>
                <button className="flex items-center space-x-2 text-gray-600 hover:text-red-500 transition-colors">
                  <Heart className="w-5 h-5" />
                  <span>Save</span>
                </button>
              </div>
              <div className="flex items-center space-x-2 text-sm text-gray-600">
                <BookOpen className="w-4 h-4" />
                <span>Article</span>
              </div>
            </div>

            {/* Article Content */}
            <div 
              className="prose prose-lg max-w-none"
              dangerouslySetInnerHTML={{ __html: article.content }}
            />

            {/* Tags */}
            <div className="mt-12 pt-8 border-t border-gray-200">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Related Topics</h3>
              <div className="flex flex-wrap gap-2">
                {article.tags.map((tag, index) => (
                  <span
                    key={index}
                    className="bg-gray-100 text-gray-700 px-3 py-1 rounded-full text-sm hover:bg-gray-200 transition-colors cursor-pointer"
                  >
                    {tag}
                  </span>
                ))}
              </div>
            </div>
          </div>
        </article>

        {/* Related Articles */}
        <div className="mt-12">
          <h2 className="text-2xl font-bold text-gray-900 mb-6">Related Articles</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {Object.values(articles)
              .filter(a => a.id !== article.id)
              .slice(0, 2)
              .map(relatedArticle => (
                <Link
                  key={relatedArticle.id}
                  to={`/womens-health/article/${relatedArticle.id}`}
                  className="bg-white rounded-lg shadow-sm overflow-hidden hover:shadow-md transition-shadow group"
                >
                  <div className="h-32 overflow-hidden">
                    <img
                      src={relatedArticle.image}
                      alt={relatedArticle.title}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                    />
                  </div>
                  <div className="p-4">
                    <h3 className="font-semibold text-gray-900 mb-2 line-clamp-2 group-hover:text-blackmores-teal transition-colors">
                      {relatedArticle.title}
                    </h3>
                    <div className="flex items-center text-xs text-gray-500 space-x-4">
                      <span>{relatedArticle.author}</span>
                      <span>{relatedArticle.readTime}</span>
                    </div>
                  </div>
                </Link>
              ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default ArticleDetailPage;