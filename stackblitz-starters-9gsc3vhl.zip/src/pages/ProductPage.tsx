import React, { useState } from 'react';
import { useParams } from 'react-router-dom';
import { Star, Plus, Minus, ShoppingCart, Heart, Truck, Shield, RefreshCw, CheckCircle } from 'lucide-react';
import { products } from '../data/products';
import { useCart } from '../context/CartContext';

const ProductPage: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const product = products.find(p => p.id === id);
  const [quantity, setQuantity] = useState(1);
  const [selectedTab, setSelectedTab] = useState('description');
  const [isSubscription, setIsSubscription] = useState(product?.isSubscription || false);
  const [deliveryFrequency, setDeliveryFrequency] = useState('Delivered every 8 weeks (20% off)');
  const [selectedImageIndex, setSelectedImageIndex] = useState(0);
  const { dispatch } = useCart();

  if (!product) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-2xl font-bold text-gray-900 mb-2">Product not found</h1>
          <p className="text-gray-600">The product you're looking for doesn't exist.</p>
        </div>
      </div>
    );
  }

  const renderStars = (rating: number) => {
    return Array.from({ length: 5 }, (_, i) => (
      <Star
        key={i}
        className={`w-5 h-5 ${
          i < Math.floor(rating) ? 'text-yellow-400 fill-current' : 'text-gray-300'
        }`}
      />
    ));
  };

  const subscriptionPrice = product.price * 0.85; // 15% discount for subscription

  // Generate multiple product images (using the same image with different query parameters for demo)
  const productImages = [
    product.image,
    `${product.image}?variant=angle1`,
    `${product.image}?variant=angle2`,
    `${product.image}?variant=back`,
    `${product.image}?variant=ingredients`
  ];

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('vi-VN', {
      style: 'currency',
      currency: 'VND',
      minimumFractionDigits: 0,
    }).format(price);
  };

  const handleAddToCart = () => {
    dispatch({
      type: 'ADD_ITEM',
      payload: {
        product,
        quantity,
        isSubscription,
        deliveryFrequency,
      },
    });
    dispatch({ type: 'TOGGLE_CART' });
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          {/* Product Image */}
          <div className="space-y-4">
            <div className="aspect-square bg-white rounded-lg shadow-sm overflow-hidden group">
              <img
                src={productImages[selectedImageIndex]}
                alt={product.name}
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
              />
            </div>
            
            {/* Thumbnail Gallery */}
            <div className="grid grid-cols-5 gap-2">
              {productImages.map((image, index) => (
                <div 
                  key={index} 
                  className={`aspect-square bg-white rounded-lg shadow-sm overflow-hidden border-2 cursor-pointer transition-all duration-200 ${
                    selectedImageIndex === index 
                      ? 'border-blackmores-teal ring-2 ring-blackmores-teal ring-opacity-50' 
                      : 'border-transparent hover:border-gray-300'
                  }`}
                  onClick={() => setSelectedImageIndex(index)}
                >
                  <img
                    src={image}
                    alt={`${product.name} view ${index + 1}`}
                    className="w-full h-full object-cover hover:scale-105 transition-transform duration-200"
                  />
                </div>
              ))}
            </div>
            
            {/* Image Navigation Dots */}
            <div className="flex justify-center space-x-2 pt-2">
              {productImages.map((_, index) => (
                <button
                  key={index}
                  onClick={() => setSelectedImageIndex(index)}
                  className={`w-2 h-2 rounded-full transition-all duration-200 ${
                    selectedImageIndex === index 
                      ? 'bg-blackmores-teal scale-125' 
                      : 'bg-gray-300 hover:bg-gray-400'
                  }`}
                />
              ))}
            </div>
          </div>

          {/* Product Details */}
          <div className="space-y-6">
            <div>
              <div className="mb-2">
                <span className="text-sm text-blackmores-teal font-medium bg-green-50 px-3 py-1 rounded-full">
                  {product.category}
                </span>
              </div>
              <h1 className="text-3xl font-bold text-gray-900 mb-4">
                {product.name}
              </h1>
              <p className="text-lg text-gray-600 leading-relaxed">
                {product.description}
              </p>
            </div>

            {/* Rating */}
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-1">
                {renderStars(product.rating)}
              </div>
              <span className="text-sm text-gray-500">
                {product.rating} ({product.reviews} reviews)
              </span>
            </div>

            {/* Subscription Toggle */}
            {product.isSubscription && (
              <div className="bg-green-50 p-4 rounded-lg border border-green-200">
                <div className="flex items-center justify-between mb-2">
                  <h3 className="font-semibold text-gray-900">Subscribe & Save</h3>
                  <label className="relative inline-flex items-center cursor-pointer">
                    <input
                      type="checkbox"
                      checked={isSubscription}
                      onChange={(e) => setIsSubscription(e.target.checked)}
                      className="sr-only peer"
                    />
                    <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blackmores-teal/30 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blackmores-teal"></div>
                  </label>
                </div>
                <p className="text-sm text-gray-600">
                  Save 30% and get free shipping on regular deliveries
                </p>
                {isSubscription && (
                  <div className="mt-3">
                    <select
                      value={deliveryFrequency}
                      onChange={(e) => setDeliveryFrequency(e.target.value)}
                      className="w-full border border-gray-300 rounded px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blackmores-teal"
                    >
                      <option value="Delivered every 8 weeks (20% off)">Delivered every 8 weeks (20% off)</option>
                      <option value="Delivered every 4 weeks (25% off)">Delivered every 4 weeks (25% off)</option>
                      <option value="Delivered every 12 weeks (15% off)">Delivered every 12 weeks (15% off)</option>
                    </select>
                  </div>
                )}
              </div>
            )}

            {/* Price */}
            <div className="space-y-2">
              <div className="flex items-center space-x-4">
                <span className="text-3xl font-bold text-gray-900">
                  {formatPrice(isSubscription ? subscriptionPrice : product.price)}
                </span>
                {product.originalPrice && (
                  <span className="text-xl text-gray-500 line-through">
                    {formatPrice(product.originalPrice)}
                  </span>
                )}
                {isSubscription && (
                  <span className="bg-green-100 text-green-800 px-2 py-1 rounded text-sm font-medium">
                    Save 30%
                  </span>
                )}
              </div>
              {isSubscription && (
                <p className="text-sm text-gray-600">
                  Delivery every 30 days (can be changed anytime)
                </p>
              )}
            </div>

            {/* Quantity and Add to Cart */}
            <div className="space-y-4">
              <div className="flex items-center space-x-4">
                <label className="text-sm font-medium text-gray-700">Quantity:</label>
                <div className="flex items-center border border-gray-300 rounded-lg">
                  <button
                    onClick={() => setQuantity(Math.max(1, quantity - 1))}
                    className="p-2 hover:bg-gray-100 transition-colors"
                  >
                    <Minus className="w-4 h-4" />
                  </button>
                  <span className="px-4 py-2 font-medium">{quantity}</span>
                  <button
                    onClick={() => setQuantity(quantity + 1)}
                    className="p-2 hover:bg-gray-100 transition-colors"
                  >
                    <Plus className="w-4 h-4" />
                  </button>
                </div>
              </div>

              <div className="flex space-x-4">
                <button 
                  onClick={handleAddToCart}
                  className="flex-1 bg-blackmores-teal text-white px-6 py-3 rounded-lg hover:bg-blackmores-teal-dark transition-colors flex items-center justify-center space-x-2 font-medium"
                >
                  <ShoppingCart className="w-5 h-5" />
                  <span>{isSubscription ? 'Subscribe Now' : 'Add to Cart'}</span>
                </button>
                <button className="p-3 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors">
                  <Heart className="w-5 h-5 text-gray-600" />
                </button>
              </div>
            </div>

          </div>
        </div>

        {/* Product Information Tabs */}
        <div className="mt-16">
          <div className="border-b border-gray-200">
            <nav className="flex space-x-8">
              {['description', 'benefits', 'ingredients', 'reviews'].map((tab) => (
                <button
                  key={tab}
                  onClick={() => setSelectedTab(tab)}
                  className={`py-4 px-1 border-b-2 font-medium text-sm capitalize transition-colors ${
                    selectedTab === tab
                      ? 'border-blackmores-teal text-blackmores-teal'
                      : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                  }`}
                >
                  {tab}
                </button>
              ))}
            </nav>
          </div>

          <div className="py-8">
            {selectedTab === 'description' && (
              <div className="prose max-w-none">
                <p className="text-gray-600 leading-relaxed text-lg">
                  {product.description}
                </p>
                <h3 className="text-xl font-semibold text-gray-900 mt-6 mb-4">How to Use</h3>
                <p className="text-gray-600">{product.dosage}</p>
              </div>
            )}

            {selectedTab === 'benefits' && (
              <div>
                <h3 className="text-xl font-semibold text-gray-900 mb-6">Key Benefits</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {product.benefits.map((benefit, index) => (
                    <div key={index} className="flex items-start space-x-3">
                      <CheckCircle className="w-5 h-5 text-blackmores-teal mt-0.5 flex-shrink-0" />
                      <span className="text-gray-700">{benefit}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {selectedTab === 'ingredients' && (
              <div>
                <h3 className="text-xl font-semibold text-gray-900 mb-6">Active Ingredients</h3>
                <div className="bg-gray-50 rounded-lg p-6">
                  <ul className="space-y-2">
                    {product.ingredients.map((ingredient, index) => (
                      <li key={index} className="text-gray-700">
                        • {ingredient}
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            )}

            {selectedTab === 'reviews' && (
              <div>
                <div className="flex items-center justify-between mb-6">
                  <h3 className="text-xl font-semibold text-gray-900">Customer Reviews</h3>
                  <button className="bg-blackmores-teal text-white px-4 py-2 rounded-lg hover:bg-blackmores-teal-dark transition-colors">
                    Write Review
                  </button>
                </div>
                <div className="space-y-6">
                  {/* Review Summary */}
                  <div className="bg-gray-50 rounded-lg p-6 mb-6">
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                      <div className="text-center">
                        <div className="text-3xl font-bold text-gray-900">{product.rating}</div>
                        <div className="flex items-center justify-center space-x-1 mb-2">
                          {renderStars(product.rating)}
                        </div>
                        <div className="text-sm text-gray-600">Based on {product.reviews} reviews</div>
                      </div>
                      <div className="md:col-span-2">
                        <div className="space-y-2">
                          {[5, 4, 3, 2, 1].map(star => (
                            <div key={star} className="flex items-center space-x-2">
                              <span className="text-sm w-8">{star}★</span>
                              <div className="flex-1 bg-gray-200 rounded-full h-2">
                                <div 
                                  className="bg-yellow-400 h-2 rounded-full" 
                                  style={{ width: `${star === 5 ? 70 : star === 4 ? 20 : star === 3 ? 7 : star === 2 ? 2 : 1}%` }}
                                ></div>
                              </div>
                              <span className="text-sm text-gray-600 w-8">
                                {star === 5 ? '70%' : star === 4 ? '20%' : star === 3 ? '7%' : star === 2 ? '2%' : '1%'}
                              </span>
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Individual Reviews */}
                  <div className="space-y-6">
                    <div className="border-b border-gray-200 pb-6">
                      <div className="flex items-start justify-between mb-3">
                        <div>
                          <div className="flex items-center space-x-2 mb-1">
                            <span className="font-medium text-gray-900">Sarah M.</span>
                            <span className="text-sm text-gray-500">Verified Purchase</span>
                          </div>
                          <div className="flex items-center space-x-1">
                            {renderStars(5)}
                          </div>
                        </div>
                        <span className="text-sm text-gray-500">2 weeks ago</span>
                      </div>
                      <h4 className="font-medium text-gray-900 mb-2">Excellent quality and results</h4>
                      <p className="text-gray-700">
                        I've been using this product for 3 months now and I'm really happy with the results. 
                        The quality is excellent and I can definitely feel the difference in my energy levels. 
                        Highly recommend!
                      </p>
                      <div className="flex items-center space-x-4 mt-3 text-sm text-gray-500">
                        <button className="hover:text-gray-700">Helpful (12)</button>
                        <button className="hover:text-gray-700">Report</button>
                      </div>
                    </div>

                    <div className="border-b border-gray-200 pb-6">
                      <div className="flex items-start justify-between mb-3">
                        <div>
                          <div className="flex items-center space-x-2 mb-1">
                            <span className="font-medium text-gray-900">Michael T.</span>
                            <span className="text-sm text-gray-500">Verified Purchase</span>
                          </div>
                          <div className="flex items-center space-x-1">
                            {renderStars(4)}
                          </div>
                        </div>
                        <span className="text-sm text-gray-500">1 month ago</span>
                      </div>
                      <h4 className="font-medium text-gray-900 mb-2">Good product, fast delivery</h4>
                      <p className="text-gray-700">
                        Great product with fast shipping. I've noticed improvements in my overall wellbeing. 
                        The subscription service is convenient and saves money. Will continue using.
                      </p>
                      <div className="flex items-center space-x-4 mt-3 text-sm text-gray-500">
                        <button className="hover:text-gray-700">Helpful (8)</button>
                        <button className="hover:text-gray-700">Report</button>
                      </div>
                    </div>

                    <div className="border-b border-gray-200 pb-6">
                      <div className="flex items-start justify-between mb-3">
                        <div>
                          <div className="flex items-center space-x-2 mb-1">
                            <span className="font-medium text-gray-900">Jennifer L.</span>
                            <span className="text-sm text-gray-500">Verified Purchase</span>
                          </div>
                          <div className="flex items-center space-x-1">
                            {renderStars(5)}
                          </div>
                        </div>
                        <span className="text-sm text-gray-500">3 weeks ago</span>
                      </div>
                      <h4 className="font-medium text-gray-900 mb-2">Trusted brand, reliable results</h4>
                      <p className="text-gray-700">
                        Blackmores has always been my go-to brand for supplements. This product is no exception - 
                        high quality, effective, and reasonably priced. Customer service is also excellent.
                      </p>
                      <div className="flex items-center space-x-4 mt-3 text-sm text-gray-500">
                        <button className="hover:text-gray-700">Helpful (15)</button>
                        <button className="hover:text-gray-700">Report</button>
                      </div>
                    </div>

                    <div className="pb-6">
                      <div className="flex items-start justify-between mb-3">
                        <div>
                          <div className="flex items-center space-x-2 mb-1">
                            <span className="font-medium text-gray-900">David K.</span>
                            <span className="text-sm text-gray-500">Verified Purchase</span>
                          </div>
                          <div className="flex items-center space-x-1">
                            {renderStars(4)}
                          </div>
                        </div>
                        <span className="text-sm text-gray-500">1 week ago</span>
                      </div>
                      <h4 className="font-medium text-gray-900 mb-2">Good value for money</h4>
                      <p className="text-gray-700">
                        Solid product at a fair price. I've been taking it for about 6 weeks and feel more energetic. 
                        The packaging is good and the tablets are easy to swallow. Would recommend to others.
                      </p>
                      <div className="flex items-center space-x-4 mt-3 text-sm text-gray-500">
                        <button className="hover:text-gray-700">Helpful (6)</button>
                        <button className="hover:text-gray-700">Report</button>
                      </div>
                    </div>
                  </div>

                  {/* Load More Reviews */}
                  <div className="text-center">
                    <button className="bg-gray-100 text-gray-700 px-6 py-2 rounded-lg hover:bg-gray-200 transition-colors">
                      Load More Reviews
                    </button>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProductPage;