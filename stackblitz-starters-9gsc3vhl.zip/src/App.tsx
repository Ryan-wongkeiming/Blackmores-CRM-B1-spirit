import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { CartProvider } from './context/CartContext';
import Header from './components/Header';
import Footer from './components/Footer';
import CartSidebar from './components/CartSidebar';
import HomePage from './pages/HomePage';
import ProductPage from './pages/ProductPage';
import CheckoutPage from './pages/CheckoutPage';
import FreeSamplePage from './pages/FreeSamplePage';
import AboutPage from './pages/AboutPage';
import WomensHealthPage from './pages/WomensHealthPage';
import ArticleDetailPage from './pages/ArticleDetailPage';
import TopicDetailPage from './pages/TopicDetailPage';
import WomensHealthProductPage from './pages/WomensHealthProductPage';
import SearchResultsPage from './pages/SearchResultsPage';

function App() {
  return (
    <CartProvider>
      <Router>
        <div className="flex flex-col min-h-screen">
          <Header />
          <main className="flex-grow">
            <Routes>
              <Route path="/" element={<HomePage />} />
              <Route path="/product/:id" element={<ProductPage />} />
              <Route path="/blackmores-subscribe" element={<ProductPage />} />
              <Route path="/free-sample" element={<FreeSamplePage />} />
              <Route path="/about" element={<AboutPage />} />
              <Route path="/checkout" element={<CheckoutPage />} />
              <Route path="/womens-health" element={<WomensHealthPage />} />
              <Route path="/womens-health/article/:id" element={<ArticleDetailPage />} />
              <Route path="/womens-health/topic/:id" element={<TopicDetailPage />} />
              <Route path="/womens-health/product/:id" element={<WomensHealthProductPage />} />
              <Route path="/search" element={<SearchResultsPage />} />
            </Routes>
          </main>
          <Footer />
          <CartSidebar />
        </div>
      </Router>
    </CartProvider>
  );
}

export default App;