import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { X, Plus, Minus, ShoppingBag, Info, ChevronDown, Check, AlertCircle, Trash2 } from 'lucide-react';
import { useCart } from '../context/CartContext';
import { validatePromoCode } from '../data/promoCodes';

const CartSidebar: React.FC = () => {
  const { state, dispatch } = useCart();
  const navigate = useNavigate();
  const [promoCode, setPromoCode] = useState('');
  const [promoError, setPromoError] = useState('');
  const [promoSuccess, setPromoSuccess] = useState('');
  const [shippingCountry, setShippingCountry] = useState('Vietnam');
  const [shippingMethod, setShippingMethod] = useState('Standard');

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('vi-VN', {
      style: 'currency',
      currency: 'VND',
      minimumFractionDigits: 0,
    }).format(price * 25000);
  };

  const calculateSubtotal = () => {
    return state.items.reduce((total, item) => {
      const price = item.isSubscription ? item.product.price * 0.7 : item.product.price;
      return total + (price * item.quantity);
    }, 0);
  };

  const calculateDiscount = () => {
    return state.items.reduce((total, item) => {
      if (item.isSubscription) {
        const discount = item.product.price * 0.3 * item.quantity;
        return total + discount;
      }
      return total;
    }, 0);
  };

  const subtotal = calculateSubtotal();
  const discount = calculateDiscount();
  const shippingCost = 0; // Set to 0 VND, can be adjusted later if needed
  const promoDiscountVND = state.promoDiscount / 25000; // Convert VND to USD for calculation
  const total = Math.max(0, subtotal + shippingCost - promoDiscountVND);
  const savings = discount + promoDiscountVND;

  const handleApplyPromoCode = () => {
    if (state.appliedPromoCode) {
      setPromoError('Chỉ được áp dụng một mã giảm giá cho mỗi đơn hàng');
      setPromoSuccess('');
      return;
    }

    if (!promoCode.trim()) {
      setPromoError('Vui lòng nhập mã giảm giá');
      setPromoSuccess('');
      return;
    }

    const validPromo = validatePromoCode(promoCode.trim());
    if (validPromo) {
      dispatch({
        type: 'APPLY_PROMO_CODE',
        payload: {
          code: validPromo.code,
          discount: validPromo.discount,
        },
      });
      setPromoSuccess(`Áp dụng thành công! Giảm ${validPromo.discount.toLocaleString('vi-VN')}đ`);
      setPromoError('');
      setPromoCode('');
    } else {
      setPromoError('Mã giảm giá không hợp lệ hoặc đã hết hạn');
      setPromoSuccess('');
    }
  };

  const handleRemovePromoCode = () => {
    dispatch({ type: 'REMOVE_PROMO_CODE' });
    setPromoSuccess('');
    setPromoError('');
  };

  const handleCheckout = () => {
    dispatch({ type: 'TOGGLE_CART' });
    navigate('/checkout');
  };

  if (!state.isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 overflow-hidden">
      <div className="absolute inset-0 bg-black bg-opacity-50" onClick={() => dispatch({ type: 'TOGGLE_CART' })} />
      
      <div className="absolute right-0 top-0 h-full w-full max-w-md bg-white shadow-xl">
        <div className="flex h-full flex-col">
          {/* Header */}
          <div className="bg-blackmores-teal px-6 py-4 text-white">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <ShoppingBag className="w-5 h-5" />
                <span className="font-semibold">
                  {state.items.length} products in your cart
                </span>
              </div>
              <button
                onClick={() => dispatch({ type: 'TOGGLE_CART' })}
                className="p-1 hover:bg-blackmores-teal-dark rounded"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
          </div>

          {/* Subscription Banner */}
          {state.items.some(item => item.product.isSubscription) && (
            <div className="bg-blue-50 px-6 py-3 border-b">
              <div className="flex items-center space-x-2">
                <Info className="w-4 h-4 text-blackmores-blue" />
                <span className="text-sm text-blackmores-blue font-medium">
                  Create a product subscription to receive 30% off plus FREE SHIPPING!
                </span>
              </div>
            </div>
          )}

          {/* Cart Items */}
          <div className="flex-1 overflow-y-auto px-6 py-4">
            {state.items.length === 0 ? (
              <div className="text-center py-12">
                <ShoppingBag className="w-12 h-12 text-gray-300 mx-auto mb-4" />
                <p className="text-gray-500">Your cart is empty</p>
              </div>
            ) : (
              <div className="space-y-4">
                {state.items.map((item) => (
                  <div key={item.product.id} className="bg-white border rounded-lg p-4">
                    <div className="flex space-x-4">
                      <img
                        src={item.product.image}
                        alt={item.product.name}
                        className="w-16 h-16 object-cover rounded"
                      />
                      <div className="flex-1">
                        <div className="flex items-start justify-between">
                          <h3 className="font-medium text-blackmores-text-dark text-sm pr-2">
                            {item.product.name}
                          </h3>
                          <button
                            onClick={() => dispatch({
                              type: 'REMOVE_ITEM',
                              payload: item.product.id
                            })}
                            className="text-gray-400 hover:text-red-500 transition-colors p-1"
                            title="Remove item"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                        <div className="flex items-center justify-between mt-2">
                          <div className="flex items-center space-x-2">
                            <button
                              onClick={() => dispatch({
                                type: 'UPDATE_QUANTITY',
                                payload: { id: item.product.id, quantity: Math.max(1, item.quantity - 1) }
                              })}
                              className="w-6 h-6 rounded-full border border-gray-300 flex items-center justify-center hover:bg-gray-50"
                            >
                              <Minus className="w-3 h-3" />
                            </button>
                            <span className="text-sm font-medium">{item.quantity} product</span>
                            <button
                              onClick={() => dispatch({
                                type: 'UPDATE_QUANTITY',
                                payload: { id: item.product.id, quantity: item.quantity + 1 }
                              })}
                              className="w-6 h-6 rounded-full border border-gray-300 flex items-center justify-center hover:bg-gray-50"
                            >
                              <Plus className="w-3 h-3" />
                            </button>
                          </div>
                          <span className="font-semibold text-blackmores-teal">
                            {formatPrice((item.isSubscription ? item.product.price * 0.7 : item.product.price) * item.quantity)}
                          </span>
                        </div>
                        
                        {item.product.isSubscription && (
                          <div className="mt-2">
                            <div className="relative">
                              <select
                                value={item.deliveryFrequency}
                                onChange={(e) => dispatch({
                                  type: 'UPDATE_SUBSCRIPTION',
                                  payload: { 
                                    id: item.product.id, 
                                    isSubscription: item.isSubscription,
                                    deliveryFrequency: e.target.value 
                                  }
                                })}
                                className="w-full text-xs border border-gray-300 rounded px-2 py-1 pr-6 appearance-none bg-white"
                              >
                                <option value="Delivered every 8 weeks (20% off)">Delivered every 8 weeks (20% off)</option>
                                <option value="Delivered every 4 weeks (25% off)">Delivered every 4 weeks (25% off)</option>
                                <option value="Delivered every 12 weeks (15% off)">Delivered every 12 weeks (15% off)</option>
                              </select>
                              <ChevronDown className="absolute right-2 top-1/2 transform -translate-y-1/2 w-3 h-3 text-gray-400 pointer-events-none" />
                            </div>
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Cart Summary */}
          {state.items.length > 0 && (
            <div className="border-t bg-blackmores-gray-light px-6 py-4 space-y-4">
              {/* Discount */}
              {discount > 0 && (
                <div className="space-y-2">
                  <h3 className="font-medium text-sm">Discount</h3>
                  <div className="flex justify-between text-sm">
                    <span>30% OFF subscription</span>
                    <span>-{formatPrice(discount)}</span>
                  </div>
                  <div className="flex justify-between font-semibold">
                    <span>Total Discount</span>
                    <span>-{formatPrice(discount)}</span>
                  </div>
                </div>
              )}

              {/* Promo Code */}
              <div className="space-y-2">
                {!state.appliedPromoCode ? (
                  <>
                    <div className="flex space-x-2">
                      <input
                        type="text"
                        value={promoCode}
                        onChange={(e) => {
                          setPromoCode(e.target.value);
                          setPromoError('');
                          setPromoSuccess('');
                        }}
                        placeholder="Nhập mã giảm giá"
                        className="flex-1 border border-gray-300 rounded px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blackmores-teal"
                      />
                      <button 
                        onClick={handleApplyPromoCode}
                        className="bg-blackmores-teal text-white px-4 py-2 rounded font-medium text-sm hover:bg-blackmores-teal-dark transition-colors"
                      >
                        Áp dụng
                      </button>
                    </div>
                    {promoError && (
                      <div className="flex items-center space-x-2 text-red-600 text-sm">
                        <AlertCircle className="w-4 h-4" />
                        <span>{promoError}</span>
                      </div>
                    )}
                    {promoSuccess && (
                      <div className="flex items-center space-x-2 text-green-600 text-sm">
                        <Check className="w-4 h-4" />
                        <span>{promoSuccess}</span>
                      </div>
                    )}
                  </>
                ) : (
                  <div className="bg-green-50 border border-green-200 rounded-lg p-3">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-2">
                        <Check className="w-4 h-4 text-green-600" />
                        <span className="text-sm font-medium text-green-800">
                          Mã: {state.appliedPromoCode}
                        </span>
                      </div>
                      <button
                        onClick={handleRemovePromoCode}
                        className="text-red-600 hover:text-red-800 text-sm font-medium"
                      >
                        Xóa
                      </button>
                    </div>
                    <p className="text-sm text-green-600 mt-1">
                      Giảm {state.promoDiscount.toLocaleString('vi-VN')}đ
                    </p>
                  </div>
                )}
              </div>

              {/* Savings */}
              {(savings > 0 || state.promoDiscount > 0) && (
                <div className="text-center py-2">
                  {savings > 0 && (
                    <div className="text-blackmores-blue font-semibold">
                      Subscription savings: {formatPrice(savings)}
                    </div>
                  )}
                  {state.promoDiscount > 0 && (
                    <div className="text-green-600 font-semibold">
                      Promo discount: {state.promoDiscount.toLocaleString('vi-VN')}đ
                    </div>
                  )}
                  {(savings > 0 || state.promoDiscount > 0) && (
                    <div className="text-blackmores-blue font-bold mt-1">
                      Total savings: {formatPrice(savings)}
                    </div>
                  )}
                </div>
              )}

              {/* Total */}
              <div className="text-center py-2 border-t">
                <span className="text-lg font-bold">
                  Total of {formatPrice(total)}
                </span>
              </div>

              {/* Action Buttons */}
              <div className="space-y-2">
                <button
                  onClick={() => dispatch({ type: 'TOGGLE_CART' })}
                  className="w-full border-2 border-blackmores-teal text-blackmores-teal py-3 rounded-full font-semibold hover:bg-blackmores-teal hover:text-white transition-colors"
                >
                  Keep shopping
                </button>
                <button 
                  onClick={handleCheckout}
                  className="w-full bg-blackmores-teal text-white py-3 rounded-full font-semibold hover:bg-blackmores-teal-dark transition-colors"
                >
                  Thanh toán
                </button>
              </div>

              {/* Free Shipping Notice */}
              <div className="text-center text-xs text-blackmores-text-medium">
                <p>Your shipping is on us!</p>
                <p>A limit of {formatPrice(50)} per order. <a href="#" className="text-blackmores-teal underline">View our Purchasing Policy here.</a></p>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default CartSidebar;