export interface PromoCode {
  code: string;
  discount: number; // in VND
  description: string;
  isActive: boolean;
}

export const promoCodes: PromoCode[] = [
  // 50,000 VND discount codes
  {
    code: 'giadinhdaudau88',
    discount: 50000,
    description: 'Giảm 50,000đ cho đơn hàng',
    isActive: true
  },
  {
    code: 'khangbaby',
    discount: 50000,
    description: 'Giảm 50,000đ cho đơn hàng',
    isActive: true
  },
  {
    code: 'meemvoiday',
    discount: 50000,
    description: 'Giảm 50,000đ cho đơn hàng',
    isActive: true
  },
  {
    code: 'captainba',
    discount: 50000,
    description: 'Giảm 50,000đ cho đơn hàng',
    isActive: true
  },
  {
    code: 'metoannang',
    discount: 50000,
    description: 'Giảm 50,000đ cho đơn hàng',
    isActive: true
  },
  // 100,000 VND discount codes
  {
    code: 'mecaheo',
    discount: 100000,
    description: 'Giảm 100,000đ cho đơn hàng',
    isActive: true
  },
  {
    code: 'sieuthitruongtho',
    discount: 100000,
    description: 'Giảm 100,000đ cho đơn hàng',
    isActive: true
  }
];

export const validatePromoCode = (code: string): PromoCode | null => {
  const promoCode = promoCodes.find(
    promo => promo.code.toLowerCase() === code.toLowerCase() && promo.isActive
  );
  return promoCode || null;
};