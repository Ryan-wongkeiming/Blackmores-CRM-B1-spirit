export interface SearchResult {
  id: string;
  title: string;
  description: string;
  type: 'Product' | 'Article' | 'Topic';
  category: string;
  url: string;
  image: string;
  price?: number;
  originalPrice?: number;
  rating?: number;
  reviews?: number;
  author?: string;
  readTime?: string;
  publishDate?: string;
}

// Import data from existing sources
import { products } from './products';

// Health hub content data
const healthHubContent: SearchResult[] = [
  {
    id: '1',
    title: 'Foods Rich in Vitamin Bs may help reduce PMS',
    description: 'Could Vitamin B be your secret weapon against PMS? Explore the science behind how these essential nutrients can help you feel better during your cycle.',
    type: 'Article',
    category: "Women's health",
    url: '/womens-health/article/1',
    image: 'https://images.pexels.com/photos/1640777/pexels-photo-1640777.jpeg?auto=compress&cs=tinysrgb&w=500',
    author: 'Dr. Sarah Johnson',
    readTime: '5 min read',
    publishDate: '2025-01-20'
  },
  {
    id: '2',
    title: 'Pre-menstrual syndrome',
    description: 'The term pre-menstrual syndrome (PMS) describes a group of physical, mental and emotional symptoms that many women experience during the 1-2 weeks before the onset of the menstrual period.',
    type: 'Topic',
    category: "Women's health",
    url: '/womens-health/topic/2',
    image: 'https://images.pexels.com/photos/3768131/pexels-photo-3768131.jpeg?auto=compress&cs=tinysrgb&w=500',
    author: 'Health Team',
    readTime: '8 min read',
    publishDate: '2023-02-21'
  },
  {
    id: '4',
    title: 'Everything to Know About Getting Off Contraception to Conceive',
    description: "Wondering how your contraceptive might impact any future plans you have around falling pregnant? To help out, we've answered a handful of commonly asked questions.",
    type: 'Article',
    category: "Women's health",
    url: '/womens-health/article/4',
    image: 'https://images.pexels.com/photos/1556691/pexels-photo-1556691.jpeg?auto=compress&cs=tinysrgb&w=500',
    author: 'Dr. Emily Chen',
    readTime: '7 min read',
    publishDate: '2023-03-08'
  },
  {
    id: '5',
    title: 'Easing pre menstrual headaches',
    description: 'Nearly 50 per cent of headaches and migraines experienced by women occur around the time of either ovulation of menstruation. This suggests a link between hormonal changes and headache or migraine occurrence.',
    type: 'Article',
    category: "Women's health",
    url: '/womens-health/article/5',
    image: 'https://images.pexels.com/photos/3768114/pexels-photo-3768114.jpeg?auto=compress&cs=tinysrgb&w=500',
    author: 'Jennifer McLennan',
    readTime: '6 min read',
    publishDate: '2024-10-30'
  },
  {
    id: '6',
    title: 'Fluid retention',
    description: 'Oedema is the swelling that occurs when fluid accumulates in the tissues. It may be localised to a certain body part, or be generalised and affect the whole body.',
    type: 'Topic',
    category: "Women's health",
    url: '/womens-health/topic/6',
    image: 'https://images.pexels.com/photos/3768131/pexels-photo-3768131.jpeg?auto=compress&cs=tinysrgb&w=500',
    author: 'Health Team',
    readTime: '6 min read',
    publishDate: '2023-02-21'
  }
];

// Convert products to search results
const productSearchResults: SearchResult[] = products.map(product => ({
  id: product.id,
  title: product.name,
  description: product.description,
  type: 'Product' as const,
  category: product.category,
  url: `/product/${product.id}`,
  image: product.image,
  price: product.price,
  originalPrice: product.originalPrice,
  rating: product.rating,
  reviews: product.reviews
}));

// Combine all search data
export const allSearchData: SearchResult[] = [
  ...productSearchResults,
  ...healthHubContent
];

// Search function
export const searchSiteContent = (query: string): SearchResult[] => {
  if (!query.trim()) return [];
  
  const searchTerm = query.toLowerCase().trim();
  
  return allSearchData.filter(item => {
    const titleMatch = item.title.toLowerCase().includes(searchTerm);
    const descriptionMatch = item.description.toLowerCase().includes(searchTerm);
    const categoryMatch = item.category.toLowerCase().includes(searchTerm);
    const authorMatch = item.author?.toLowerCase().includes(searchTerm) || false;
    
    return titleMatch || descriptionMatch || categoryMatch || authorMatch;
  });
};

// Get search suggestions (for autocomplete)
export const getSearchSuggestions = (query: string, limit: number = 5): string[] => {
  if (!query.trim()) return [];
  
  const searchTerm = query.toLowerCase().trim();
  const suggestions = new Set<string>();
  
  allSearchData.forEach(item => {
    // Add title suggestions
    if (item.title.toLowerCase().includes(searchTerm)) {
      suggestions.add(item.title);
    }
    
    // Add category suggestions
    if (item.category.toLowerCase().includes(searchTerm)) {
      suggestions.add(item.category);
    }
    
    // Add author suggestions
    if (item.author && item.author.toLowerCase().includes(searchTerm)) {
      suggestions.add(item.author);
    }
  });
  
  return Array.from(suggestions).slice(0, limit);
};