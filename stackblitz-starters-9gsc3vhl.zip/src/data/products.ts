export interface Product {
  id: string;
  name: string;
  description: string;
  price: number;
  originalPrice?: number;
  image: string;
  category: string;
  benefits: string[];
  ingredients: string[];
  dosage: string;
  rating: number;
  reviews: number;
  inStock: boolean;
  isSubscription?: boolean;
}

export const products: Product[] = [
  {
    id: 'blackmores-subscribe',
    name: 'Blackmores Subscribe & Save',
    description: 'Get your favourite Blackmores products delivered regularly with exclusive subscriber benefits and savings.',
    price: 1149750,
    image: 'https://images.pexels.com/photos/3683074/pexels-photo-3683074.jpeg?auto=compress&cs=tinysrgb&w=500',
    category: 'Subscription Service',
    benefits: [
      'Save up to 30% on every order',
      'Free shipping on all deliveries',
      'Flexible delivery schedule',
      'Priority customer support',
      'Exclusive subscriber-only products'
    ],
    ingredients: ['Varies by selected products'],
    dosage: 'As per individual product instructions',
    rating: 4.8,
    reviews: 1247,
    inStock: true,
    isSubscription: true
  },
  {
    id: 'Blackmores Newborn Formula',
    name: 'Blackmores Newborn Formula',
    description: 'Blackmores® Newborn Formula has been developed with a special blend of nutrients to help meet the nutritional needs of your baby from birth to 6 months.',
    price: 639000,
    image: 'https://www.blackmores.com.vn/-/media/4e275bc6175a48faa126ce812cb371f8.png?h=1000&iar=0&w=1000&hash=0623BD25DE25CF502AB432BE9500E2ED',
    category: 'Infant Formula',
    benefits: [
      'Supports bone health',
      'Maintains immune system function',
      'Supports muscle strength',
      'Aids calcium absorption'
    ],
    ingredients: ['Cholecalciferol (Vitamin D3) 25 micrograms (1000 IU)'],
    dosage: 'Adults: Take 1 capsule daily with food',
    rating: 4.6,
    reviews: 892,
    inStock: true
  },
  {
    id: 'Blackmores Follow-on Formula',
    name: 'Blackmores Follow-on Formula',
    description: 'Blackmores Follow-on Formula has been developed with a special blend of nutrients to help meet the nutritional needs of your baby from 6 to 12 months.',
    price: 639000,
    image: 'https://www.blackmores.com.vn/-/media/862e5de903484adc97c317b68ce6a45e.png',
    category: 'Infant Formula',
    benefits: [
      'Supports heart health',
      'Maintains brain function',
      'Supports eye health',
      'Anti-inflammatory properties'
    ],
    ingredients: [
      'Fish Oil 1500mg',
      'Providing Omega-3 marine triglycerides 450mg',
      'EPA 270mg, DHA 180mg'
    ],
    dosage: 'Adults: Take 1 capsule daily with food',
    rating: 4.7,
    reviews: 1156,
    inStock: true
  },
  {
    id: 'Blackmores Toddler Milk Drink',
    name: 'Blackmores Toddler Milk Drink',
    description: 'Blackmores® Toddler Milk Drink contains the essential vitamins and minerals to support your growing toddler`s nutritional needs.',
    price: 619000,
    image: 'https://www.blackmores.com.vn/-/media/e99de2f89c514e0b9fe2e6410055dc3e.png',
    category: 'Infant Formula',
    benefits: [
      'Supports energy production',
      'Maintains general wellbeing',
      'Supports immune function',
      'Assists with stress management'
    ],
    ingredients: [
      'Vitamin B1, B2, B3, B5, B6, B12',
      'Vitamin C, Vitamin D3',
      'Iron, Magnesium, Zinc'
    ],
    dosage: 'Adults: Take 1 tablet daily with breakfast',
    rating: 4.5,
    reviews: 743,
    inStock: true
  },
  {
    id: 'calcium-magnesium-d3',
    name: 'Calcium Magnesium + D3',
    description: 'Complete bone health formula combining calcium, magnesium and vitamin D3 for optimal absorption.',
    price: 899750,
    originalPrice: 1074750,
    image: 'https://images.pexels.com/photos/3683074/pexels-photo-3683074.jpeg?auto=compress&cs=tinysrgb&w=500',
    category: 'Minerals',
    benefits: [
      'Supports bone density',
      'Maintains muscle function',
      'Supports nerve transmission',
      'Aids calcium absorption'
    ],
    ingredients: [
      'Calcium carbonate 500mg',
      'Magnesium oxide 200mg',
      'Vitamin D3 400IU'
    ],
    dosage: 'Adults: Take 2 tablets daily with meals',
    rating: 4.4,
    reviews: 567,
    inStock: true
  },
  {
    id: 'probiotics-daily',
    name: 'Daily Probiotics 30 Billion',
    description: 'High-potency probiotic formula with 30 billion live cultures to support digestive and immune health.',
    price: 1149750,
    image: 'https://images.pexels.com/photos/3683074/pexels-photo-3683074.jpeg?auto=compress&cs=tinysrgb&w=500',
    category: 'Probiotics',
    benefits: [
      'Supports digestive health',
      'Maintains gut flora balance',
      'Supports immune function',
      'Aids nutrient absorption'
    ],
    ingredients: [
      'Lactobacillus acidophilus 10 billion CFU',
      'Bifidobacterium lactis 10 billion CFU',
      'Lactobacillus plantarum 10 billion CFU'
    ],
    dosage: 'Adults: Take 1 capsule daily with food',
    rating: 4.6,
    reviews: 892,
    inStock: true
  },
  {
    id: 'iron-plus',
    name: 'Iron Plus with Vitamin C',
    description: 'Gentle iron supplement enhanced with vitamin C for better absorption and reduced stomach upset.',
    price: 624750,
    image: 'https://images.pexels.com/photos/3683074/pexels-photo-3683074.jpeg?auto=compress&cs=tinysrgb&w=500',
    category: 'Minerals',
    benefits: [
      'Supports healthy iron levels',
      'Reduces tiredness and fatigue',
      'Supports oxygen transport',
      'Maintains energy levels'
    ],
    ingredients: [
      'Iron bisglycinate 24mg',
      'Vitamin C 60mg',
      'Folic acid 400mcg'
    ],
    dosage: 'Adults: Take 1 tablet daily with food',
    rating: 4.3,
    reviews: 445,
    inStock: true
  },
  {
    id: 'zinc-immune',
    name: 'Zinc Immune Support',
    description: 'High-strength zinc supplement to support immune function and wound healing.',
    price: 499750,
    originalPrice: 624750,
    image: 'https://images.pexels.com/photos/3683074/pexels-photo-3683074.jpeg?auto=compress&cs=tinysrgb&w=500',
    category: 'Minerals',
    benefits: [
      'Supports immune function',
      'Aids wound healing',
      'Supports skin health',
      'Maintains taste and smell'
    ],
    ingredients: [
      'Zinc gluconate 25mg',
      'Providing elemental zinc 3.5mg'
    ],
    dosage: 'Adults: Take 1 tablet daily with food',
    rating: 4.2,
    reviews: 334,
    inStock: true
  },
  {
    id: 'coq10-heart',
    name: 'CoQ10 Heart Health',
    description: 'Premium CoQ10 supplement to support cardiovascular health and cellular energy production.',
    price: 1324750,
    image: 'https://images.pexels.com/photos/3683074/pexels-photo-3683074.jpeg?auto=compress&cs=tinysrgb&w=500',
    category: 'Vitamins',
    benefits: [
      'Supports heart health',
      'Maintains cellular energy',
      'Antioxidant protection',
      'Supports muscle function'
    ],
    ingredients: [
      'Coenzyme Q10 150mg'
    ],
    dosage: 'Adults: Take 1 capsule daily with food',
    rating: 4.7,
    reviews: 678,
    inStock: true
  },
  {
    id: 'turmeric-curcumin',
    name: 'Turmeric Curcumin Complex',
    description: 'High-potency turmeric extract with black pepper for enhanced absorption and anti-inflammatory support.',
    price: 974750,
    image: 'https://images.pexels.com/photos/3683074/pexels-photo-3683074.jpeg?auto=compress&cs=tinysrgb&w=500',
    category: 'Herbs',
    benefits: [
      'Natural anti-inflammatory',
      'Supports joint health',
      'Antioxidant protection',
      'Supports digestive health'
    ],
    ingredients: [
      'Turmeric root extract 500mg',
      'Curcumin 95% 475mg',
      'Black pepper extract 5mg'
    ],
    dosage: 'Adults: Take 2 capsules daily with meals',
    rating: 4.5,
    reviews: 789,
    inStock: true
  },
  {
    id: 'magnesium-sleep',
    name: 'Magnesium Sleep Support',
    description: 'Chelated magnesium formula designed to promote relaxation and support quality sleep.',
    price: 724750,
    image: 'https://images.pexels.com/photos/3683074/pexels-photo-3683074.jpeg?auto=compress&cs=tinysrgb&w=500',
    category: 'Minerals',
    benefits: [
      'Promotes relaxation',
      'Supports quality sleep',
      'Maintains muscle function',
      'Supports nervous system'
    ],
    ingredients: [
      'Magnesium glycinate 400mg',
      'Providing elemental magnesium 80mg'
    ],
    dosage: 'Adults: Take 2 tablets 30 minutes before bed',
    rating: 4.4,
    reviews: 523,
    inStock: true
  },
  {
    id: 'vitamin-b-complex',
    name: 'B-Complex Energy Formula',
    description: 'Complete B-vitamin complex to support energy metabolism and nervous system function.',
    price: 674750,
    originalPrice: 799750,
    image: 'https://images.pexels.com/photos/3683074/pexels-photo-3683074.jpeg?auto=compress&cs=tinysrgb&w=500',
    category: 'Vitamins',
    benefits: [
      'Supports energy production',
      'Maintains nervous system',
      'Supports mental clarity',
      'Aids stress management'
    ],
    ingredients: [
      'Thiamine (B1) 25mg',
      'Riboflavin (B2) 25mg',
      'Niacin (B3) 50mg',
      'Pyridoxine (B6) 25mg',
      'Cobalamin (B12) 100mcg'
    ],
    dosage: 'Adults: Take 1 tablet daily with breakfast',
    rating: 4.3,
    reviews: 612,
    inStock: true
  },
  {
    id: 'glucosamine-chondroitin',
    name: 'Glucosamine Chondroitin MSM',
    description: 'Triple-action joint support formula with glucosamine, chondroitin and MSM for optimal joint health.',
    price: 1074750,
    image: 'https://images.pexels.com/photos/3683074/pexels-photo-3683074.jpeg?auto=compress&cs=tinysrgb&w=500',
    category: 'Herbs',
    benefits: [
      'Supports joint health',
      'Maintains cartilage',
      'Supports mobility',
      'Reduces joint stiffness'
    ],
    ingredients: [
      'Glucosamine sulfate 1500mg',
      'Chondroitin sulfate 1200mg',
      'MSM 1000mg'
    ],
    dosage: 'Adults: Take 3 tablets daily with meals',
    rating: 4.6,
    reviews: 834,
    inStock: true
  },
  {
    id: 'evening-primrose-oil',
    name: 'Evening Primrose Oil 1000mg',
    description: 'Cold-pressed evening primrose oil rich in GLA to support women\'s health and skin condition.',
    price: 849750,
    image: 'https://images.pexels.com/photos/3683074/pexels-photo-3683074.jpeg?auto=compress&cs=tinysrgb&w=500',
    category: 'Herbs',
    benefits: [
      'Supports women\'s health',
      'Maintains skin condition',
      'Supports hormonal balance',
      'Rich in essential fatty acids'
    ],
    ingredients: [
      'Evening Primrose Oil 1000mg',
      'Providing GLA 100mg'
    ],
    dosage: 'Adults: Take 2 capsules daily with meals',
    rating: 4.4,
    reviews: 456,
    inStock: true
  },
  {
    id: 'milk-thistle-liver',
    name: 'Milk Thistle Liver Support',
    description: 'Standardized milk thistle extract to support liver health and natural detoxification processes.',
    price: 799750,
    image: 'https://images.pexels.com/photos/3683074/pexels-photo-3683074.jpeg?auto=compress&cs=tinysrgb&w=500',
    category: 'Herbs',
    benefits: [
      'Supports liver health',
      'Aids natural detoxification',
      'Antioxidant protection',
      'Supports liver regeneration'
    ],
    ingredients: [
      'Milk Thistle extract 150mg',
      'Standardized to 80% silymarin'
    ],
    dosage: 'Adults: Take 1 capsule twice daily with meals',
    rating: 4.5,
    reviews: 387,
    inStock: true
  },
  {
    id: 'cranberry-uti',
    name: 'Cranberry Urinary Health',
    description: 'Concentrated cranberry extract to support urinary tract health and maintain bladder function.',
    price: 699750,
    originalPrice: 824750,
    image: 'https://images.pexels.com/photos/3683074/pexels-photo-3683074.jpeg?auto=compress&cs=tinysrgb&w=500',
    category: 'Herbs',
    benefits: [
      'Supports urinary tract health',
      'Maintains bladder function',
      'Natural antioxidants',
      'Supports immune function'
    ],
    ingredients: [
      'Cranberry extract 25000mg',
      'Equivalent to fresh cranberries'
    ],
    dosage: 'Adults: Take 1 capsule daily with water',
    rating: 4.3,
    reviews: 298,
    inStock: true
  },
  {
    id: 'ginkgo-memory',
    name: 'Ginkgo Biloba Memory Support',
    description: 'Standardized ginkgo biloba extract to support cognitive function and mental clarity.',
    price: 749750,
    image: 'https://images.pexels.com/photos/3683074/pexels-photo-3683074.jpeg?auto=compress&cs=tinysrgb&w=500',
    category: 'Herbs',
    benefits: [
      'Supports cognitive function',
      'Maintains mental clarity',
      'Supports circulation',
      'Antioxidant protection'
    ],
    ingredients: [
      'Ginkgo Biloba extract 120mg',
      'Standardized to 24% flavonoids'
    ],
    dosage: 'Adults: Take 1 tablet daily with food',
    rating: 4.2,
    reviews: 445,
    inStock: false
  },
  {
    id: 'garlic-cardiovascular',
    name: 'Odourless Garlic Heart Health',
    description: 'Odourless garlic extract to support cardiovascular health and maintain healthy cholesterol levels.',
    price: 574750,
    image: 'https://images.pexels.com/photos/3683074/pexels-photo-3683074.jpeg?auto=compress&cs=tinysrgb&w=500',
    category: 'Herbs',
    benefits: [
      'Supports heart health',
      'Maintains cholesterol levels',
      'Supports circulation',
      'Immune system support'
    ],
    ingredients: [
      'Garlic extract 2000mg',
      'Equivalent to fresh garlic'
    ],
    dosage: 'Adults: Take 2 tablets daily with meals',
    rating: 4.1,
    reviews: 356,
    inStock: true
  },
  {
    id: 'echinacea-immune',
    name: 'Echinacea Immune Defence',
    description: 'Premium echinacea extract to support natural immune system function and seasonal wellness.',
    price: 649750,
    originalPrice: 749750,
    image: 'https://images.pexels.com/photos/3683074/pexels-photo-3683074.jpeg?auto=compress&cs=tinysrgb&w=500',
    category: 'Herbs',
    benefits: [
      'Supports immune function',
      'Seasonal wellness support',
      'Natural defence system',
      'Antioxidant properties'
    ],
    ingredients: [
      'Echinacea purpurea extract 400mg',
      'Standardized to 4% phenolics'
    ],
    dosage: 'Adults: Take 1 tablet twice daily',
    rating: 4.4,
    reviews: 523,
    inStock: true
  },
  {
    id: 'green-tea-antioxidant',
    name: 'Green Tea Extract Antioxidant',
    description: 'Concentrated green tea extract rich in EGCG for powerful antioxidant protection and metabolism support.',
    price: 874750,
    image: 'https://images.pexels.com/photos/3683074/pexels-photo-3683074.jpeg?auto=compress&cs=tinysrgb&w=500',
    category: 'Herbs',
    benefits: [
      'Powerful antioxidant protection',
      'Supports metabolism',
      'Maintains cellular health',
      'Supports weight management'
    ],
    ingredients: [
      'Green Tea extract 500mg',
      'Providing EGCG 200mg',
      'Caffeine 50mg'
    ],
    dosage: 'Adults: Take 1 capsule daily with food',
    rating: 4.5,
    reviews: 667,
    inStock: true
  }
];

export const categories = [
  'All Products',
  'Subscription Service',
  'Vitamins',
  'Fish Oil',
  'Multivitamins',
  'Minerals',
  'Herbs',
  'Probiotics',
  'Infant Formula'
];